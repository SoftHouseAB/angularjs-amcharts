/**
 * Created by jaswath on 28-05-2016.
 */
angular.module('charts', ['amChartsDirective']);
